typedef struct{double x; double y; double z;} vec;
