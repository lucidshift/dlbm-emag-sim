#ifndef KOORD3D_H
#define KOORD3D_H

extern void Koordinatensystem3D(int c,double xmin, double xmax,
                    double ymin, double ymax,
                    double zmin, double zmax,
		    double sx, double sy, double sz,	 
                    char *xstr, char *ystr, char *zstr,
                    char *xstru, char *ystru, char *zstru);

#endif
