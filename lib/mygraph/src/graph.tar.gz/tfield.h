#ifndef TFIELD_H
#define TFIELD_H

extern void tfield(int anzy,int xmin, int xmax, int ymin, int ymax,
	    double *t,double scale,
	    int xofs, int yofs, int xsize, int ysize,int rough);

#endif
